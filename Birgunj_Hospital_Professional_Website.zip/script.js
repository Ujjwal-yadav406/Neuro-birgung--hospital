const toggle=document.querySelector('.menu-toggle');
const links=document.querySelector('.nav-links');
toggle?.addEventListener('click',()=>links.classList.toggle('open'));
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));

const form=document.getElementById('appointmentForm');
form?.addEventListener('submit',e=>{
  e.preventDefault();
  const data=new FormData(form);
  const text=`Appointment request from ${data.get('name')} (${data.get('phone')})%0AService: ${data.get('service')}%0ADate: ${data.get('date')||'Not specified'}%0A${data.get('message')||''}`;
  const subject=encodeURIComponent('Appointment Request - Birgunj Hospital');
  window.location.href=`mailto:neurogeneral2024@gmail.com?subject=${subject}&body=${text}`;
});
